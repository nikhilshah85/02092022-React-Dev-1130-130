import { Component } from 'react';
import PostData from './Components/postdata';

class App extends Component
{

    constructor()
    {
      super();

      this.state = {
        firstName:'Nikhil',   
        techList:['React','Angular','Node'],
        postData:[]
      }
    this.changeName = this.changeName.bind(this);
    this.addNewTech = this.addNewTech.bind(this);
    this.getPostData = this.getPostData.bind(this);
    }


    getPostData()
    {
      //fetch is a standard api for all the browser
      fetch('https://jsonplaceholder.typicode.com/posts').then(respose => respose.json())
                                                        .then(data => {
                                                          alert('Got the data');
                                                console.log(data);                                                
                                                this.state.postData = data;
                                                   console.log(this.state.postData);
                                                        })
                                                        .catch(err => {
                                                          alert('Errorrrrr !!');
                                                        })
    }

    addNewTech()
    {
        var newT = document.getElementById("txt_newTectName").value;
        var currentList = this.state.techList;
        currentList.push(newT);
        this.setState({techList:currentList});
    }

    changeName()
    {
      // var currentName = document.getElementById('').value;
      alert('UI works fine');

      this.setState({firstName:'Nikhil Shah is the new Name'});
    }

    render(){

      
      return(<div>
        <button onClick={this.changeName}>Change Name</button>
        <h1> {this.state.firstName} </h1>

        <hr/>
        <input type="text" placeholder="Enter New Technology Name" id="txt_newTectName"/>
        <button onClick={this.addNewTech}> Add</button>

        <ul>
          {this.state.techList.map(t => <li> {t }</li>)}
        </ul>

        <hr/>


        <button onClick={this.getPostData}>Get Post</button>
        {/* <PostData pst={this.state.postData}></PostData> */}

        <table>
                {this.state.postData.map(p => <tr>
                    <td> { p.userId }</td>
                    <td> { p.id }</td>
                    <td> { p.title }</td>
                    <td> { p.body }</td>
                </tr>)}
            </table>
      </div>)
    }


}

export default App;
