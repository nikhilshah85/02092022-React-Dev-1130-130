import { Component } from "react";




class PostData extends Component
{

    // constructor(props)
    // {

    //     super(props);
    // }

    render(){
        
        return(<div>

            
            {/* <table>
                {this.props.pst.map(p => <tr>
                    <td> { p.userId }</td>
                    <td> { p.id }</td>
                    <td> { p.title }</td>
                    <td> { p.body }</td>
                </tr>)}
            </table> */}
        </div>)
    }

}

export default PostData;