import logo from './logo.svg';
import './App.css';
import { Component } from 'react';
import MensProduct from './Components/Mensproduct';
import WomensProduct from './Components/Womensproduct';
import KidsProduct from './Components/Kidsproduct';

class App extends Component
{

  mensProduct=[];
  womensProduct=[];
  KidsProduct=[];

  totalProducts =0;
  totalMensProduct = 0;
  totalWomensProduct  = 0;
  totalKidsProduct = 0;
  constructor()
  {
    super();
    this.state = {
      pList :[
        {pId:101,pName:'Hair Gel',pCategory:'Mens', pPrice:600},
        {pId:102,pName:'Shoes',pCategory:'Mens', pPrice:4000},
        {pId:103,pName:'Sandals',pCategory:'Women', pPrice:6000},
        {pId:104,pName:'Eye Lashes',pCategory:'Women', pPrice:950},
        {pId:105,pName:'Baby Pants',pCategory:'Kids', pPrice:750},
        {pId:106,pName:'Belt',pCategory:'Mens', pPrice:1650},
        {pId:107,pName:'T-Shirt',pCategory:'Women', pPrice:800},
        {pId:108,pName:'Turban',pCategory:'Kids', pPrice:1200},    
      ],     
    }

    {this.seperateProducts()}
  }

  seperateProducts()
  {
    for (let index = 0; index < this.state.pList.length; index++) {

      this.totalProducts = this.totalProducts + 1;
      if(this.state.pList[index].pCategory == 'Mens')
      {
        this.totalMensProduct = this.totalMensProduct + 1;
        this.mensProduct.push(this.state.pList[index]);
      }
      else if(this.state.pList[index].pCategory == 'Women')
      {
        this.totalWomensProduct = this.totalWomensProduct + 1;
        this.womensProduct.push(this.state.pList[index]);
      }
      else{
        this.totalKidsProduct = this.totalKidsProduct + 1;
        this.KidsProduct.push(this.state.pList[index]);
      }

    }
  }

  render(){
    
    return(<div>

        <h1> Total Products For Sale : {this.totalProducts }</h1>
      <MensProduct products={this.mensProduct} totalProducts={this.totalMensProduct}></MensProduct>

      <hr/>

      <WomensProduct products={this.womensProduct} totalProducts={this.totalWomensProduct}></WomensProduct>

      <hr/>

      <KidsProduct products={this.KidsProduct} totalProducts={this.totalKidsProduct}></KidsProduct>


      {/* 
      <table>
        {this.mensProduct.map(p => <tr>
            <td> {p.pId} </td>
            <td> {p.pName} </td>
            <td> {p.pCategory} </td>
            <td> {p.pPrice} </td>
            
            </tr>)}  
      
      </table>

      <h1> Womens Products </h1>
      <table>
        {this.womensProduct.map(p => <tr>
            <td> {p.pId} </td>
            <td> {p.pName} </td>
            <td> {p.pCategory} </td>
            <td> {p.pPrice} </td>
            
            </tr>)}  
      
      </table>
          <hr/>
      <h1> Kids Products </h1>
      <table>
        {this.KidsProduct.map(p => <tr>
            <td> {p.pId} </td>
            <td> {p.pName} </td>
            <td> {p.pCategory} </td>
            <td> {p.pPrice} </td>
            
            </tr>)}  
      
      </table>
       */}
    </div>)
  }


}

export default App;





