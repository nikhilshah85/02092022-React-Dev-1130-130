import { Component } from "react";




class ProjectDetails extends Component
{

    constructor(props){
        super(props);
    }

    render(){
        return(
        <div className="projectDetails">
            <button onClick={this.props.greetings}>Project Details</button>
            <h1> Project Details - {this.props.project }</h1>

            <h3> Develoeper : { this.props.developerName }</h3>
            <h3> Total Developers : { this.props.totalDevelopers }</h3>
            <ul>
                {this.props.technology.map(t => <li> {t}</li>)}
                
            </ul>
        </div>
        )
    }
}
export default ProjectDetails;