import { Component } from "react";



class ProjectCostDetails extends Component
{


    render(){
        return(<div className="projectCost">
            
      <button onClick={this.props.greetings}>Cost Greet</button>
                <h1> Total Cost (M$): {this.props.finance.revenue} </h1>
                <h1> Duration : {this.props.finance.duration} </h1>
                <h1> Tax ({this.props.finance.tax}%): {this.props.finance.revenue * (this.props.finance.tax / 100)} </h1>
                <h1> Profit ({this.props.finance.margin}%): {this.props.finance.revenue * (this.props.finance.margin / 100)} </h1>


        </div>)
    }
}

export default ProjectCostDetails;