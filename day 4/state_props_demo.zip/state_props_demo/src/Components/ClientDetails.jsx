import { Component } from "react";
import ProjectCostDetails from "./ProjectCostDetails";



class ClientDetails extends Component
{

    render(){
        return(<div className="clientDetails">
            <button onClick={this.props.greetings}>Client Greet </button>
            <h4> Client : {this.props.client.clientName} ({this.props.client.clientId})</h4>
            <h4> Location : {this.props.client.clientLocation}</h4>
            <h4> Point Of Connect : {this.props.client.clientConnect}</h4>
            <hr/>
            <ProjectCostDetails finance={this.props.client.projectCost}
                               greetings={this.props.greetings}></ProjectCostDetails>
        </div>)
    }
}

export default ClientDetails;