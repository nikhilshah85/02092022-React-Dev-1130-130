import logo from './logo.svg';
import './App.css';
import { Component } from 'react';
import ProjectDetails from './Components/projectDetails';
import ClientDetails from './Components/ClientDetails';



class App extends Component
{  

  constructor(){
    super();
    //data will come from Rest API calls
    this.state = {
      appName:'React Demo - State and Props',
      developer:'Nikhil',
      techList:['React','Angular','.Net','SQL Server','Azure'],
      teamStrength: 20,
      clientDetails:{clientId:'AZ9078JI', 
                    clientName:'ABYFashion',
                    clientLocation:'Hemstead, London UK',
                    clientConnect:'Evelyn M',
                    projectCost:{
                        revenue: 12000000,
                        margin:8,
                        duration:'7 Months',
                        tax:24
                                }
                   },
        greetUser:function(){
          alert('Hello This is a funcion from state');
        }
    }
  }
  render(){
    return(<div>
      
      <h1> {this.state.appName }</h1> 
      <button onClick={this.state.greetUser}>APP Greet</button>
      <ProjectDetails developerName={this.state.developer}
                      technology = {this.state.techList}
                      totalDevelopers = {this.state.teamStrength}
                      project={this.state.clientDetails.clientName}
                      greetings={this.state.greetUser}></ProjectDetails>

      <hr/>
      <ClientDetails client={this.state.clientDetails}
                     greetings={this.state.greetUser} ></ClientDetails>

                    
    </div>)
  }

}

export default App;
